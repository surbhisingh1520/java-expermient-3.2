// ====== Part B: Hibernate CRUD Application ======
package com.example.hibernatecrud;

import javax.persistence.*;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

// ---- Student.java ----
@Entity
@Table(name = "Student")
class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "name")
    private String name;

    @Column(name = "age")
    private int age;

    public Student() {}
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
}

// ---- StudentDAO.java ----
class StudentDAO {
    private static SessionFactory factory = new Configuration().configure().buildSessionFactory();

    public void addStudent(Student s) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(s);
        tx.commit();
        session.close();
        System.out.println("Student added successfully!");
    }

    public Student getStudent(int id) {
        Session session = factory.openSession();
        Student s = session.get(Student.class, id);
        session.close();
        return s;
    }

    public void updateStudent(int id, String newName) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        Student s = session.get(Student.class, id);
        s.setName(newName);
        session.update(s);
        tx.commit();
        session.close();
        System.out.println("Student updated successfully!");
    }

    public void deleteStudent(int id) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        Student s = session.get(Student.class, id);
        session.delete(s);
        tx.commit();
        session.close();
        System.out.println("Student deleted successfully!");
    }
}

// ---- MainApp.java ----
public class HibernateMain {
    public static void main(String[] args) {
        StudentDAO dao = new StudentDAO();

        // Create
        dao.addStudent(new Student("Aryan", 21));

        // Read
        Student s = dao.getStudent(1);
        System.out.println("Fetched Student: " + s.getName());

        // Update
        dao.updateStudent(1, "Aryan Yadav");

        // Delete
        dao.deleteStudent(1);
    }
}
