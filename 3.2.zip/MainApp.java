// ====== Part A: Dependency Injection in Spring ======
package com.example.springdemo;

import org.springframework.context.annotation.*;

// ---- Course.java ----
class Course {
    private String courseName;
    public Course(String courseName) { this.courseName = courseName; }
    public void displayCourse() {
        System.out.println("Enrolled in course: " + courseName);
    }
}

// ---- Student.java ----
class Student {
    private Course course;
    public Student(Course course) { this.course = course; }
    public void showDetails() {
        System.out.println("Student is successfully registered.");
        course.displayCourse();
    }
}

// ---- AppConfig.java ----
@Configuration
class AppConfig {
    @Bean
    public Course course() {
        return new Course("Java Spring Framework");
    }

    @Bean
    public Student student() {
        return new Student(course());
    }
}

// ---- MainApp.java ----
public class MainApp {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(AppConfig.class);
        Student student = context.getBean(Student.class);
        student.showDetails();
        context.close();
    }
}
